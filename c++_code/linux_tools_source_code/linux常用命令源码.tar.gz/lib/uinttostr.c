#define inttostr uinttostr
#define inttype unsigned int
#define inttype_is_signed 0
#include "inttostr.c"
